#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/opt/ros/devel_isolated/rqt_action:$CMAKE_PREFIX_PATH"
export ROSLISP_PACKAGE_DIRECTORIES="/opt/ros/devel_isolated/rqt_action/share/common-lisp"
export ROS_PACKAGE_PATH="/opt/ros/src/rqt_action:$ROS_PACKAGE_PATH"