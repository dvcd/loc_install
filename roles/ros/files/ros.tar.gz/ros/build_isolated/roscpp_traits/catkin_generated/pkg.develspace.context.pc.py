# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/opt/ros/src/roscpp_core/roscpp_traits/include".split(';') if "/opt/ros/src/roscpp_core/roscpp_traits/include" != "" else []
PROJECT_CATKIN_DEPENDS = "cpp_common;rostime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "roscpp_traits"
PROJECT_SPACE_DIR = "/opt/ros/devel_isolated/roscpp_traits"
PROJECT_VERSION = "0.5.8"
