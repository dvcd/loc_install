# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/opt/ros/src/rviz/src;/usr/include/eigen3;/usr/include/OGRE;/usr/include".split(';') if "/opt/ros/src/rviz/src;/usr/include/eigen3;/usr/include/OGRE;/usr/include" != "" else []
PROJECT_CATKIN_DEPENDS = "geometry_msgs;image_geometry;image_transport;interactive_markers;laser_geometry;map_msgs;message_filters;nav_msgs;pluginlib;resource_retriever;roscpp;roslib;sensor_msgs;std_msgs;tf;urdf;visualization_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lrviz;-l:/usr/lib/x86_64-linux-gnu/libOgreMain.so;-l:/usr/lib/x86_64-linux-gnu/libpthread.so;-l:/usr/lib/x86_64-linux-gnu/libGLU.so;-l:/usr/lib/x86_64-linux-gnu/libGL.so".split(';') if "-lrviz;-l:/usr/lib/x86_64-linux-gnu/libOgreMain.so;-l:/usr/lib/x86_64-linux-gnu/libpthread.so;-l:/usr/lib/x86_64-linux-gnu/libGLU.so;-l:/usr/lib/x86_64-linux-gnu/libGL.so" != "" else []
PROJECT_NAME = "rviz"
PROJECT_SPACE_DIR = "/opt/ros/devel_isolated/rviz"
PROJECT_VERSION = "1.11.18"
