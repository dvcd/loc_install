# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/opt/ros/install_isolated/include".split(';') if "/opt/ros/install_isolated/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rosconsole;rospy;tf;visualization_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-linteractive_markers".split(';') if "-linteractive_markers" != "" else []
PROJECT_NAME = "interactive_markers"
PROJECT_SPACE_DIR = "/opt/ros/install_isolated"
PROJECT_VERSION = "1.11.3"
