# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/opt/ros/src/interactive_markers/include".split(';') if "/opt/ros/src/interactive_markers/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rosconsole;rospy;tf;visualization_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-linteractive_markers".split(';') if "-linteractive_markers" != "" else []
PROJECT_NAME = "interactive_markers"
PROJECT_SPACE_DIR = "/opt/ros/devel_isolated/interactive_markers"
PROJECT_VERSION = "1.11.3"
