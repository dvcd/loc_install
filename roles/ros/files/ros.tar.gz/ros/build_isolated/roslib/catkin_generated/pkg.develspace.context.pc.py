# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/opt/ros/src/ros/roslib/include".split(';') if "/opt/ros/src/ros/roslib/include" != "" else []
PROJECT_CATKIN_DEPENDS = "rospack".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lroslib".split(';') if "-lroslib" != "" else []
PROJECT_NAME = "roslib"
PROJECT_SPACE_DIR = "/opt/ros/devel_isolated/roslib"
PROJECT_VERSION = "1.11.14"
