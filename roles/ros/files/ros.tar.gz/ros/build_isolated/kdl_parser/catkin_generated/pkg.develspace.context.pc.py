# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/opt/ros/src/kdl_parser/kdl_parser/include;/usr/include/eigen3;/opt/ros/install_isolated/include;/usr/include".split(';') if "/opt/ros/src/kdl_parser/kdl_parser/include;/usr/include/eigen3;/opt/ros/install_isolated/include;/usr/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rosconsole;urdf".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lkdl_parser;-l:/opt/ros/install_isolated/lib/liborocos-kdl.so.1.3.0;-l:/usr/lib/x86_64-linux-gnu/libtinyxml.so".split(';') if "-lkdl_parser;-l:/opt/ros/install_isolated/lib/liborocos-kdl.so.1.3.0;-l:/usr/lib/x86_64-linux-gnu/libtinyxml.so" != "" else []
PROJECT_NAME = "kdl_parser"
PROJECT_SPACE_DIR = "/opt/ros/devel_isolated/kdl_parser"
PROJECT_VERSION = "1.11.14"
