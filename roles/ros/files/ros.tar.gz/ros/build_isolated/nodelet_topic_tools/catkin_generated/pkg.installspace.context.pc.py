# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/opt/ros/install_isolated/include;/usr/local/include".split(';') if "/opt/ros/install_isolated/include;/usr/local/include" != "" else []
PROJECT_CATKIN_DEPENDS = "dynamic_reconfigure;message_filters;nodelet;pluginlib;roscpp".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-l:/usr/local/lib/libboost_thread.so;-l:/usr/local/lib/libboost_chrono.so;-l:/usr/local/lib/libboost_system.so;-l:/usr/local/lib/libboost_date_time.so;-l:/usr/local/lib/libboost_atomic.so".split(';') if "-l:/usr/local/lib/libboost_thread.so;-l:/usr/local/lib/libboost_chrono.so;-l:/usr/local/lib/libboost_system.so;-l:/usr/local/lib/libboost_date_time.so;-l:/usr/local/lib/libboost_atomic.so" != "" else []
PROJECT_NAME = "nodelet_topic_tools"
PROJECT_SPACE_DIR = "/opt/ros/install_isolated"
PROJECT_VERSION = "1.9.10"
