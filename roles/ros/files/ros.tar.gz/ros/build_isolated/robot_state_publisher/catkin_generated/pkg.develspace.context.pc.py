# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/opt/ros/src/robot_state_publisher/include;/usr/include/eigen3;/opt/ros/install_isolated/include".split(';') if "/opt/ros/src/robot_state_publisher/include;/usr/include/eigen3;/opt/ros/install_isolated/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rosconsole;rostime;tf2_ros;tf2_kdl;kdl_parser".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lrobot_state_publisher_solver;-l:/opt/ros/install_isolated/lib/liborocos-kdl.so.1.3.0".split(';') if "-lrobot_state_publisher_solver;-l:/opt/ros/install_isolated/lib/liborocos-kdl.so.1.3.0" != "" else []
PROJECT_NAME = "robot_state_publisher"
PROJECT_SPACE_DIR = "/opt/ros/devel_isolated/robot_state_publisher"
PROJECT_VERSION = "1.11.2"
