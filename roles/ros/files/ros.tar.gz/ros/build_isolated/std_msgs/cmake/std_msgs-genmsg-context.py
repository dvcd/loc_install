# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/opt/ros/src/std_msgs/msg/Bool.msg;/opt/ros/src/std_msgs/msg/Byte.msg;/opt/ros/src/std_msgs/msg/ByteMultiArray.msg;/opt/ros/src/std_msgs/msg/Char.msg;/opt/ros/src/std_msgs/msg/ColorRGBA.msg;/opt/ros/src/std_msgs/msg/Duration.msg;/opt/ros/src/std_msgs/msg/Empty.msg;/opt/ros/src/std_msgs/msg/Float32.msg;/opt/ros/src/std_msgs/msg/Float32MultiArray.msg;/opt/ros/src/std_msgs/msg/Float64.msg;/opt/ros/src/std_msgs/msg/Float64MultiArray.msg;/opt/ros/src/std_msgs/msg/Header.msg;/opt/ros/src/std_msgs/msg/Int16.msg;/opt/ros/src/std_msgs/msg/Int16MultiArray.msg;/opt/ros/src/std_msgs/msg/Int32.msg;/opt/ros/src/std_msgs/msg/Int32MultiArray.msg;/opt/ros/src/std_msgs/msg/Int64.msg;/opt/ros/src/std_msgs/msg/Int64MultiArray.msg;/opt/ros/src/std_msgs/msg/Int8.msg;/opt/ros/src/std_msgs/msg/Int8MultiArray.msg;/opt/ros/src/std_msgs/msg/MultiArrayDimension.msg;/opt/ros/src/std_msgs/msg/MultiArrayLayout.msg;/opt/ros/src/std_msgs/msg/String.msg;/opt/ros/src/std_msgs/msg/Time.msg;/opt/ros/src/std_msgs/msg/UInt16.msg;/opt/ros/src/std_msgs/msg/UInt16MultiArray.msg;/opt/ros/src/std_msgs/msg/UInt32.msg;/opt/ros/src/std_msgs/msg/UInt32MultiArray.msg;/opt/ros/src/std_msgs/msg/UInt64.msg;/opt/ros/src/std_msgs/msg/UInt64MultiArray.msg;/opt/ros/src/std_msgs/msg/UInt8.msg;/opt/ros/src/std_msgs/msg/UInt8MultiArray.msg"
services_str = ""
pkg_name = "std_msgs"
dependencies_str = ""
langs = "gencpp;genlisp;genpy"
dep_include_paths_str = "std_msgs;/opt/ros/src/std_msgs/msg"
PYTHON_EXECUTABLE = "/usr/bin/python"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/install_isolated/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
