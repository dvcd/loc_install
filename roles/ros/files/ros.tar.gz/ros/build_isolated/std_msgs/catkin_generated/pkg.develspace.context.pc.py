# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/opt/ros/devel_isolated/std_msgs/include;/opt/ros/src/std_msgs/include".split(';') if "/opt/ros/devel_isolated/std_msgs/include;/opt/ros/src/std_msgs/include" != "" else []
PROJECT_CATKIN_DEPENDS = "message_runtime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "std_msgs"
PROJECT_SPACE_DIR = "/opt/ros/devel_isolated/std_msgs"
PROJECT_VERSION = "0.5.10"
