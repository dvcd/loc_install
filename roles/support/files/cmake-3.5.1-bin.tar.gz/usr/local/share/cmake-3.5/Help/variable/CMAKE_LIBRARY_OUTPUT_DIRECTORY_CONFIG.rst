CMAKE_LIBRARY_OUTPUT_DIRECTORY_<CONFIG>
---------------------------------------

Where to put all the :ref:`LIBRARY <Library Output Artifacts>`
target files when built for a specific configuration.

This variable is used to initialize the
:prop_tgt:`LIBRARY_OUTPUT_DIRECTORY_<CONFIG>` property on all the targets.
See that target property for additional information.
