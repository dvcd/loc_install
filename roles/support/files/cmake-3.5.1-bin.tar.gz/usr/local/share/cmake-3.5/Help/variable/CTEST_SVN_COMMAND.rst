CTEST_SVN_COMMAND
-----------------

Specify the CTest ``SVNCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
