CMAKE_STANDARD_LIBRARIES
------------------------

Libraries linked into every executable and shared library.

This is the list of libraries that are linked into all executables and
libraries.
