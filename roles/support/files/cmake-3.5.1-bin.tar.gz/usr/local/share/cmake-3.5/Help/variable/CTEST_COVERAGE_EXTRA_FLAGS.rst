CTEST_COVERAGE_EXTRA_FLAGS
--------------------------

Specify the CTest ``CoverageExtraFlags`` setting
in a :manual:`ctest(1)` dashboard client script.
