CTEST_CVS_UPDATE_OPTIONS
------------------------

Specify the CTest ``CVSUpdateOptions`` setting
in a :manual:`ctest(1)` dashboard client script.
