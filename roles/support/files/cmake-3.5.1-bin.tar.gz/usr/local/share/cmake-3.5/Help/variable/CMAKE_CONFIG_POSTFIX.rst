CMAKE_<CONFIG>_POSTFIX
----------------------

Default filename postfix for libraries under configuration ``<CONFIG>``.

When a non-executable target is created its :prop_tgt:`<CONFIG>_POSTFIX`
target property is initialized with the value of this variable if it is set.
