CMAKE_GENERATOR
---------------

The generator used to build the project.  See :manual:`cmake-generators(7)`.

The name of the generator that is being used to generate the build
files.  (e.g.  ``Unix Makefiles``, ``Visual Studio 6``, etc.)
